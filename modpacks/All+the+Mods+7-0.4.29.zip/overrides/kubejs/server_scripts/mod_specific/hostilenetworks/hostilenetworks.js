onEvent('recipes', event => {
  removeRecipeByID(event, [
    'hostilenetworks:living_matter/hellish/blaze_rod',
    'hostilenetworks:living_matter/extraterrestrial/nether_star',
  ]);
})
